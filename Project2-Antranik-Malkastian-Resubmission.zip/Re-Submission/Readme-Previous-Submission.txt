Anto Malkastian

Dijistra code running isntructions and comments:

GitHub repo link: https://github.com/amalkast/Planning---Project2


Libraries:
import numpy as np
import matplotlib.pyplot as plt
import pygame


Run the code in pycharm:

This will promt the user for inputs, kindly input desired start and ends points and press enter every time.
Next, you will see the obstacle map pop out. Kindly close this window and code will continue to run.


Unfortunately, I ran into many debugging issues and spent hours trying to fix it. I am confident however that my algorithm method is implemented corretly, and I was observing the nodes change as the dijistra nodes were being explored.
 
As mentioend, because of debugging issues, I was not able to implement the full solution. But please consider finding sections of the code that represent my undertanding and implementation, you can see I was mostly debugging with many print statements.

The visulation part is at the end, but since I was not able to get to the final solution, I was not able to show any.

Thank you.


