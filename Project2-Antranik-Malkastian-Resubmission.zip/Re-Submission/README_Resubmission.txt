Anto (Antranik) Malkastian
ENPM 661 - Re-Sumbittion of Project 2
NOTE: I have most of my algorithm the same as my previous submission before the deadline. In this iteration, I fixed many bugs, and added the visualisation part that I meant to do in the previous submission. I was not able to plot visualisation in the previous subimssion, because there were too many debugging issues.
The content of the code is similar, but with more added details and presentation examples.

- RED are the nodes that are being updated
- BLUE at the end is the backtracking
- You could see the path being filled with black and obstacles left with white.

- The "Smaller.py" file worked with starting point 0,0 and goal 2,5. It has a good visualisation example too.
Other points worked as well, but there is still a bug that appears when trying long distances. It could be related to the coordinates.

-"bigger_new.py" uses the bigger coordinates. It takes a while to load the initial image, but it's the exact same code as "Smaller.py" otherwise. (Smaller.py has 40 x 25, bigger has 400 x 250, with adjusted obstacle sizes.)

- When plotting in pygame, seems like the coordinates are baased on the image coordinates instead. In other words, (2,5) appears in the top left corner (image coordinates), instead of lower left corner.
I would have looked into this issue as future tasks.

- Unfortunatley I also did not address the 5mm boundary. But I would have checked for it by looking forward 4 points, and checking if that point exists in the graph or obstacle (1 or 0 of the "image" I created in my code.) So if I moved say right 5 times, I would obtain a new node, and I would check if that existed in the graph.
To avoid adding more debugging issues like my previous submission, I avoided addid this detail, but hope my explanation will get the point accross.

- Similary, I did not plot a hexagon, and instead replaced it with a circle. I did read hexagon equations, and thought about plotting one with multiple triangles since I had that working. But because of time constraints personally, I did not implement this detail since I wanted to spend most of my time on the algorithm development.


